ARsnakesHarmful = ["Copperhead", "Northern Cottonmouth", "Texas Coral Snake", "Pigmy Rattlesnake", "Timber Rattlesnake", "Diamondback Rattlesnake", "Boomslang"]

ARsnakesHarmless = ["Western Ratsnake", "Prarie Kingsnake", "Eastern Hognose","Speckled Kingsnake", "Great plains Ratsnake", "Garter Snake", "Ribbon Snake", "Lined Snake", "Dekay's Brownsnake", "Mudsnake", "Queensnake", "Wormsnake", "Crayfish Snake", "Ringneck Snake", "Gulf Swamp Snake","Southern Black Racer", "Rough Green Snake"]

ARsnakesNerodia = ["Mississippi Green Watersnake", "Diamondback Watersnake", "Midland Watersnake", "Plain-bellied Watersnake", "Broad-banded Watersnake"]

ARsnakesHarmless.append(ARsnakesNerodia)

ARsnakesHarmful.remove("Boomslang")

ARsnakes = []
ARsnakes.append(ARsnakesHarmful)
ARsnakes.append(ARsnakesHarmless)


ARsnakes.sort()

print(ARsnakes)


favoritesnakevars = input("What is your favorite snake")
favoritesnake = []
favoritesnake.append(favoritesnakevars)
print(favoritesnake)