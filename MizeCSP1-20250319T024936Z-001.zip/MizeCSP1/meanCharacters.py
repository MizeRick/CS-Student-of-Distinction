class Characters:
    def __init__(self, health, strength, sneak, intelligence, charisma):
        self.health = health
        self.strength = strength
        self.sneak = sneak
        self.intelligence = intelligence
        self.charisma = charisma
    def Warlord(self, health, strength, sneak, intelligence, charisma):
        self.health= 450
        self.strength = 10
        self.sneak = 1
        self.intelligence = 7
        self.charisma = 4
    def Rival():
        health = 300
        strength = 6
        sneak = 6
        intelligence = 6
        charisma = 6
    
    
Warlord = Characters(450,10,1,7,4)
Rival = Characters(300,6,6,6,6)
King = Characters(100,1,10,10,10)
Thug = Characters(150,5,2,2,2)
Assassin = Characters(250,7,10,8,2)