class Math:
    def __init__(self, x, y, z):
      self.x = x
      self.y = y
      self.z = z

    def add(self, x, y):
      return x + y
    def subtract(self, x, y):
      return x - y
    def multiply(self,x,y):
       return(x*y)
    def square(self,x):
       return x**2
    def divide(self, x, y):
       return x/y
    def modulo(self, x, y):
       return x%y
    def squarearea(self, x, y):
       return x*y
    def areaofCircle(self, x):
       return (x**2)*3.141592653589
    def areaofCube(self, x,y,z):
       return x*y*z
    def perimeterofrectangle(self,x,y):
       return (x*2)+(y*2)
    def sqrroot(self,x):
       return x**.5
    def areaofcircle(self,x):
       return(3.14159265358*x**2)
    def volumeofprism(self,x,y,z):
       return(x*y*z)
    def volumeofcone(self,x,y):
       return(.33*y*3.14159265358*x**2)
    def residual(self,x,y):
      return(x-y)
   
    
math = Math(1,2,3)

print(math.sqrroot(7))