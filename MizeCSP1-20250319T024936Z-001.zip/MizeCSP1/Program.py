Name = input("What is your name? ")

class Characters:
    def __init__(self, name, health, strength, sneak, intelligence, charisma):
        self.name = name
        self.health = health
        self.strength = strength
        self.sneak = sneak
        self.intelligence = intelligence
        self.charisma = charisma
Warlord = Characters("Warlord",450,10,1,7,4)
Dragon = Characters("Dragon",1000, 10,1,10,6)
King = Characters("King",100,1,10,10,10)
Mentor = Characters("Mentor",150,4,3,10,6)
Informant = Characters("Informant", 200,5,10,9,10)
Tavernkeep = Characters("Tavern Keep",180,6,4,8,9)
Cat = Characters("Cat",50,1,10,8,1)
User = Characters(Name,200,5,5,5,5)
FeebleRabidDog = Characters("Dog",50,1,1,1,1)
Snake = Characters("Snake",100,5,5,5,5)
Bear = Characters("Bear", 500, 10,10,10,10)

Inventory = []


def context():
    print("In Eldoria, a once-vibrant kingdom, power struggles have left the land in disarray.")
    print("After the royal family vanished, various factions-each with their own ambitions-now vie for dominance.")
    print("The Heart of Aether, a legendary artifact rumored to bestow great power, is said to be hidden somewhere within the kingdom.")
    print("You, a lost soul, will brave these challenges in your attempt to acquire the Heart")
    print("Whether it be to retore order to the kingdom, or impose your own authority over The World...")


def awakening():
    global Inventory
    while True:
        print("You awaken to a faint meow within a ramshackle barn")
        decision1 = input("Brushing off the hay that adorns you, you find a cat looking upon you curiously. You hear the barn door sliding open. What do you do? 1 for hide, 2 for wait, 3 for fight ")
        Inventory.append(Cat)
        print("You place the cat into your bag, he is now yours")
        if(decision1 == "1"):
            print("Hiding behind the stack of hay, you see a grayed fellow walk into the barn. He looks upon the makeshift cot you were on moments ago. He notices the Cat staring at you, and approaches")
            conversation()
        elif(decision1 == "2"):
            print("An elderly man walks into the barn, he sees you and greets you with the hint of a smile.")
            conversation()
        elif(decision1 == "3"):
            print("An elderly man walks into the barn. You were prepared, and attempt to hit him with a stick you found, but he simply knocks it away and hits you on the head")
            User.intelligence -= 1
            conversation()
        else:
            print("invalid input")

def conversation():
    while True:
        print("The elderly fellow looks at you, and asks a simple question.")
        decision2 = input("Who are you? 1 for 'I don't know', 2 for Run, 3 for 'No, who are you?'")
        if(decision2 == "1"):
            print("You seem to have lost you memories, go outside and take a look around")
            OldFarm()
        elif(decision2 == "2"):
            print("You escape through the door")
            OldFarm()
        elif(decision2 == "3"):
            print("I am simply a farmer, perhaps you should go outside and take a look around")
            OldFarm()

def OldFarm():

    print("Upon leaving the barn, fields of gray surround you. Dead fields where crops used to be define the landscape, and a sense of dread engulfs you.")
    print("You hear wind rushing around the area, followed by a thunderous boom. It seems to be just over a hill.")
    while True:
        decision3 = input("Would you like to investigate? 1 for yes, 2 for no ")
        if(decision3 == "1"):
            print("You crest the hill, a gargantuan beast rest in a crater, presumably created by his rather harsh landing. It appears to be a dragon of myth.")
            while True:
                decision4 = input("Would you like to fight it(not recomended)? 1 for yes, 2 for no ")
                if(decision4 == "1"):
                    print("You are slaughtered, there was no one to save you.")
                    awakening()
                elif(decision4 == "2"): 
                    print("The Dragon turns. You would have been spotted if not for the Mentor grabbing you and pulling you out of view. You thank him and begin to head the other direction, the cat comes with you")
                    town()
                else:
                    print("invalid input")
                    continue
        elif(decision3 =="2"):
            print("You turn around and head the other direction, the cat comes with you")
            town()
        else:
            print("Invalid input")
            continue

            
def town():
    print("You are in the local town of Lamplight")
    print("You find the local tavernkeep always open and willing to give information, he gives your cat a snack")
    Cat.health +=100
    decision5 = input("There is a lake to the north, a cemetary to the west, a forest to the south, and the old king's castle is to the east. 1 for north, 2 for west, 3 for south, 4 for east ")
    while True:
        if(decision5 == "1"):
            lake()
        elif(decision5 == "2"):
            cemetary()
        elif(decision5 == "3"):
            forest()
        elif(decision5 == "4"):
            dragonfight()
        else:
            print("Invalid Input")
            continue

def dragonfight():
        print("As you walk along the path, a scaled beast descends from the sky. There is nowhere to hide. You must fight!")
        while True:
            decision10 = input("What will you do? 1 to run, 2 to throw rocks, 3 to call for help: ")
            if decision10 == "1":
                if User.sneak > 5: 
                    print("You manage to sneak away from the Dragon!")
                    town()
                    break
                else:
                    print("You're not fast enough to escape!")
                    awakening() 
            elif decision10 == "2":
                if User.strength > 5: 
                    print("You throw a rock at the Dragon! It hits, and he falls to the ground, blocking your path")
                    Dragon.health -= 1000
                    town()
                    break
                else:
                    print("The rock has no effect. The Dragon roars with fury!")
                    awakening()
            elif decision10 == "3":
                print("The old man from the barn steps in, saving your life. He defeats the Dragon, but the way to the castle is blocked by its body.")
                town()
                break 
            else:
                print("Invalid input")
                continue

def forest():
    print("You arrive in the forest")
    print("After wandering for hours you decided you got lost")
    print("you need to chose a direction to get out of the forest")
    
    while True:
        decision12 = input("What way would you like to go? 1 for Left, 2 for right, 3 for straight")
        if(decision12 == "1"):
            print("you start to walk left marking each tree as you pass, minutes later you start to see those same markings.")
            print("You walked in a circle, you are back to square 1")
            forest()

        elif(decision12 == "2"):
            print("You decide to go right")
            print("Each step you take seems weary but you continue either way")
            print("After minutes of walking, you finally discover the caverns")
            caverns()

        elif(decision12 == "3"):
            print("The path was clear, or so you thought.")
            print("Soon you hear footsteps, but they aren't yours. These are heavier...louder...and getting closer")
            print("Suddenly you hear a ROAR.")
            print("You turn around and see a bear")
            while True:
                decision13 = input("You come to the conclusion that you need to cause a distraction. What will you do? 1 sacrifice the cat, 2 for hide, 3 for fight")
                
                if (decision13 == "1"):
                    print("You throw the cat at the bear")
                    print("stunned by your cowardice, the bear lunges at you")
                    awakening()

                elif (decision13 == "2"):
                    print("You decide to hide.")
                    print("You hide behind a large rock, careful not to make a sound.")
                    print("As time passes by the air becomes still, you know that the bear is gone but when you get up you realize your back to square 1")
                    forest()

                elif(decision13 == "3"):
                    if (User.strength >= 7):
                        print("You won!")
                        print("But you realize your back to where you started")
                        forest()
        else:
            print("Invalid input")
            continue

def town2():
    print("You arrive in the local town of Lamplight")
    print("the locals gossip of how the cemetary was mysteriously destroyed, and the road there is now impassable")
    print("You find the local tavernkeep always open and willing to give information, he gives your cat a snack")
    Cat.health +=100
    decision5 = input("There is a lake to the north, a forest to the south, and the old king's castle is to the east. 1 for north, 2 for south, 3 for east ")
    while True:
        if(decision5 == "1"):
            lake()
        elif(decision5 == "2"):
            forest()
        elif(decision5 == "3"):
            castle()
        else:
            print("Invalid Input")
            continue

def dogfight():
    print("The rabid dog decides to attack you")
    FeebleRabidDog.health -=100
    while True:
        if( FeebleRabidDog.health <=0):
            print("the rabid dog has died of natural causes")
            lake2()
        else:
            continue

def lake2():
    while True:
        lakedecision = input ("Which direction would you like to go? 1 east, 2 west, 3 for south ")
        if(lakedecision == "1"):
            battlefield()

        elif(lakedecision == "2"):
            swamps()
        elif(lakedecision == "3"):
            town()
        else:
            print("Invalid Input")
            continue


def lake():
    print("You arrive to the lake")
    print("You strole along the humid lake, each step follwing another. As you slowly make your way to the side you hear a faint growl.")
    while True:
        decision6 = input ("Would you like to investigate? 1 for yes, 2 for no ")
        if(decision6 == "1"):
            print("You decide to investigate despite the fear that follows.")
            print("As you continue to walk your eyes form a small shadow in the distance.")
            print("Suddenly it starts to run.")
            dogfight()        
        elif(decision6 == "2"):
            print("The fear consumes you so decide to leave.")
            lake2()
        else:
            print("Invalid Input")
            continue



def battlefield():
    print("You arrive to the battelfield")
    print("Upon a ground lain with remains, you see a shine from some rubble. An ancient legendary blade sits upon the ground.")
    while True:
        decisionfield = input("Would you like to pull the sword out of the ground? 1 for yes, 2 for no ")
        if(decisionfield == "1"):
            if(User.strength >= 6):
                print("You collect the sword and head back to the lake")
                Inventory.append("sword")
                lake2()
            if(User.strength <6):
                print("You are too weak")
                lake2()

def cemetary():
    print("You walk into the old cemetary. There is clearly no one tending to the stones. A gleaming obilisk stands in the middle of the graves, you cannot help but investigate")
    decision7 = input("A vision flashes in front of your eyes, you may upgrade one skill. 1 for health, 2 for strength, 3 for sneak, 4 for intelligence, 5 for charisma ")
    while True:
        if(decision7 == "1"):
            User.health += 50
            break
        elif(decision7 == "2"):
            User.strength += 1
            break
        elif(decision7 == "3"):
            User.sneak += 1
            break
        elif(decision7 == "4"):
            User.intelligence += 1
            break
        elif(decision7 == "5"):
            User.charisma += 1
            break
        else:
            print("invalid input")
            continue
    print("With a new sense of power, you head back to the town")
    town2()


def swamps():
    print("You arive in the swamps")
    decision8 =input("There is a large snake, would you like to fight it? 1 for yes, 2 for no ")
    if(decision8 == "1"):
        SnakeFight()
    if(decision8 == "2"):
        while True:
            decision9 = input("Where do  you run? 1 for town, 2 for lake ")
            if(decision9 == "1"):
                town2()
            elif(decision9 == "2"):
                lake2()
            else:
                print("invalid input")
                continue

def SnakeFight():
    while True:
        print("The snake Bites you")
        User.health -= 20
        decision9 = input("How would you like to attack? 1 for punch, 2 for slice, 3 for insult ")
        if(decision9 == "1"):
            Snake.health = Snake.health - 3*User.strength
        elif(decision9 == "2"):
            Snake.health = Snake.health - 3*User.sneak
        elif(decision9 == "3"):
            Snake.health = Snake.health - 3*User.charisma
        else:
            print("Invalid input detected")
            continue
        if(Snake.health <= 0):
            print("The Snake has died")
            print("You absorb the power of the defeated serpent")
            User.health += 150
            User.strength += 2
            User.sneak += 2
            User.charisma += 1
            User.intelligence += 1 
            lake3()
        elif(User.health <= 0):
            awakening()
        else: 
            continue

def lake3():
    while True:
        print("You travel back to the Lake")
        lakedecision1 = input ("Which direction would you like to go? 1 east, 2 for south ")
        if(lakedecision1 == "1"):
            battlefield()
        elif(lakedecision1 == "2"):
            town()
        else:
            print("Invalid Input")
            continue

while True:
    play = input("Press 1 to play ")
    if(play == "1"):
        context()
        break
    else:
        continue

def bandittown():
    print("you arrive into a town of bandits")
    print("The area was decrepit, with runned down buildings and the lingering scent of alcohol")
    print("As you walk deeper and deeper into the town, you see a tall shadow")
    print("you stop, afraid of what is to happen next")
    print("As it gets closer, the figure becomes more defined. You come face to face with a scrawny man, whos face is unknown, hidden by the thick black cloak")
    print("I will tell you how to get to the castle, if you have what I need.")
    
    item = "sword"
    item2 = "crown"
    if item in Inventory:
        Inventory.remove("sword")
        print("follow the path northeast to your last respite and you will find an entrance.")
        lastrespite()
    elif item2 in Inventory:
        Inventory.remove("crown")
        print("follow the path northeast to your last respite and you will find an entrance.")
        lastrespite()
    else:
        print("You don't have what I need. Be on your way.")

def caverns():
    print("You arrive to the caverns")
    print("water drips from the sinking ground above you")
    print("you see a crown laying upon the floor. A few feet away stands the old king, hiding from the kingdom above")
    kingconvo = input("What will you say? 1 - Why are you here,   2- prepare to die   3- Ignore him ")
    if(kingconvo == "1"):
        print("The king puts his hands up, without a word he lunges at you")
        kingfight()
    elif(kingconvo == "2"):
        print("The king lunges at you")
        kingfight()
    else:
        print("You walk past the king and wander to the light at the end of the cave")
        bandittown()
    

def kingfight():
    fight = input("How will you attack? 1 for punch, 2 for stab, 3 for insult")
    while True:
        if(King.health <= 0):
            print("The King has fallen")
            print("You take his crown")
            Inventory.append("Crown")
            print("You absorb the King's power, gaining health, charisma, strength, and intelligence")
            User.health += 150
            User.charisma += 4
            User.strength =+ 1 
            User.intelligence += 3
            break
        elif((User.health <= 0)):
            awakening()
            break
        print("The king punches you")
        print("Your health is", User.health)
        if(fight == "1"):
            King.health -= User.strength * 3
            print("The king's health is", King.health)
        elif(fight =="2"):
            King.health -= User.sneak *3
            print("The kings health is", King.health)
        elif(fight == "3"):
            King.health -= User.charisma *3
            print("The king's health is", King.health)
        

def lastrespite():
    print("You arrive to a campfire")
    print("In the distance you see a familiar face")
    print("It's the old man from the barn")
    while True:
        decisionfire = input("Do you chose to talk to the old man? 1 for talk to the old man, 2 for no i don't want to talk to him")

        
        if(decisionfire == "1"):
            print("You chose to approach and talk to the old man")
            print("The old man talks about preparing you for the battle that comes ahead")
            print("The old man gives you a riddle")
            while True:
                riddle = input("Seen once in a year, twice in a week, but never in a day; what is it?")
                if(riddle == "e"):
                    User.health += 100
                    User.strength += 1
                    User.sneak += 1
                    User.intelligence += 1
                    User.charisma += 1
                    castle()
                else:
                    print("Try again")
                    continue
        else:
            print("You chose not to talk to the old man and instead walk by him")
            castle()

def castle():
    print("Your arduous journey has brought you here, the castle. A black door stands in your way; it speaks to you")
    while True:
        fire = input("It is not alive, but able to grow; It has no lungs, but requires air; it cannot drown, but falters when faced with water; What is it?")
        if(fire == "fire"):
            print("You enter the castle.Sitting is a warlord, holding a gleaming stone, the heart.")
            warlordfight()
            break
        else:
            print("Try again")
            continue

def warlordfight():
    print("You have made such a journey, only to be stopped here. This heart is mine")
    print("The man readies himself for battle")
    while True:
        if(Warlord.health <= 0):
            print("You have defeated the warlord, the heart is yours")
            finalscene()
        if(User.health <= 0):
            print("you lose")
            awakening()
        print("The Warlord strikes you")
        User.health -=20
        print(User.health)
        warfight = input("How would you like to attack? 1- punch, 2- dagger, 3- chemicals, 4- insult")
        if(warfight == "1"):
            print("you strike the Warlord")
            Warlord.health -= User.strength *4
            print("The warlord's health is", Warlord.health)
            continue
        elif(warfight == "2"):
            print("You slash the Warlord")
            Warlord.health -= User.sneak *4
            print("The warlord's health is", Warlord.health)
            continue        
        elif(warfight == "3"):
            print("You use a chemical formula to hurt the Warlord")
            Warlord.health -= User.intelligence *4
            print("The warlord's health is", Warlord.health)
            continue
        elif(warfight == "4"):
            print("You say mean things about the Warlord")
            Warlord.health -= User.charisma *4
            print("The warlord's health is", Warlord.health)
            continue
        else:
            print("Your attack misses")
            continue




   
def finalscene():
    if "crown" in Inventory:
        choice = input("What will you do with the heart? 1- Absorb it, 2- Put it into the crown ")
        if(choice == 1):
            print("The heart is absorbed into you, and you gain immense understanding of the world. The walls of the castle crumble, the earths cracks and falls into itself")
            print("In your final moments, you realize the heart was never meant to be possessed, it belonged to the world. The sky darkens, the sun is gone, nothing is here. It all fades to black")
            print("what have you done...")
            awakening()
        else:
            Inventory.remove("crown")
            print("The crown holds the heart perfectly. It dissipates, gold flakes travelling with the wind")
            print("The war is over, while it may take time, things will return to normal")
            print("Congratulations", User.name, "you saved the kingdom")
    else:
        print("The heart is absorbed into you, and you gain immense understanding of the world. The walls of the castle crumble, the earths cracks and falls into itself")
        print("In your final moments, you realize the heart was never meant to be possessed, it belonged to the world. The sky darkens, the sun is gone, nothing is here. It all fades to black")
        print("what have you done...")
        awakening()
    
   
   
   
   
awakening()



