


PasswordRepository = {
}


    
def ask():
    while True:
        input1 = input("What would you like to do? 1 for add password, 2 for remove password, 3 for retrieve password, Quit to end the program: ")
        
        if(input1 == "QUIT" or input1 == "quit" or input1 == "Quit" or PasswordRepository >= 10):
            break
        elif(input1 == "1"):
            addpassword()
        elif(input1 == "2"):
            removepassword()
        elif(input1 == "3"):
            retrieve()
        else:
            print("try again")



def addpassword():
    input2 = input("What is your username? ")
    if input2 in PasswordRepository:
        print("Username already exists. Password will be updated.")
    
    input4 = input("What is your password? ")
    PasswordRepository[input2] = input4
    print(f"Password for {input2} has been added/updated.")

def removepassword():
    input5 = input("What is your username? ")
    
    
    if input5 in PasswordRepository:
        input6 = input("What is your password? ")

        if PasswordRepository[input5] == input6:
            del PasswordRepository[input5]
            print(f"Password for {input5} has been removed.")
        else:
            print("Incorrect password. Cannot remove the password.")
    else:
        print("Username not found.")

def retrieve():
    input7 = input("What is your username? ")
    if input7 in PasswordRepository:
        print(f"The password for {input7} is {PasswordRepository[input7]}")
    else:
        print("Username not found.")

ask()