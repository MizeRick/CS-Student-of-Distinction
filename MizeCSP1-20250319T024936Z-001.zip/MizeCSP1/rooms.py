def Lobby():
    print("You are the Lobby of the Museum")
    direction = input("What Exhibit would you like to visit? Type: 1 for Farming, 2 for Natural, 3 for Technology, 4 for Gift Shop ")
    if(direction == "1"):
        Farm()
    if(direction == "2"):
        Natural()
    if(direction == "3"):
        Technology()
    if(direction == "4"):
        GiftShop()
    else:
        Lobby()
def Farm():
    direction = input("You are in the farming section of the mueseum, what subsection would you like to visit? Type: 1 for Lobby, 2 for farm shop, 3 for the crop room, 4 for Farm Tech")
    if(direction == "1"):
        Lobby()
    if(direction == "2"):
        FarmShop()
    if(direction == "3"):
        CropRoom()
    if(direction == "4"):
        FarmTech()
    else:
        Farm()
def Natural():
    direction = input("You are now in the natural science section, what subsection would you like to visit? 1 for Lobby, 2 for natural shop, 3 for creatures, and 4 for ancient tech")
    if(direction == "1"):
        Lobby()
    if(direction == "2"):
        NaturalShop()
    if(direction == "3"):
        Creatures()
    if(direction == "4"):
        AncientTech()
    else:
        Natural()
def Technology():
    direction = input("You are now in the Tech section, what subsection would you like to visit? 1 for Lobby, 2 for Ancient Tech, 3 for Computers, and 4 for Farm Tech")
    if(direction == "1"):
        Lobby()
    if(direction == "2"):
        AncientTech()
    if(direction == "3"):
        Computers()
    if(direction == "4"):
        FarmTech()
    else:
        Technology()
def GiftShop(): 
    direction = input("You are now in the Gift Shop, what subsection would you like to visit?  1 for Lobby, 2 for Nat Shop, 3 for Farm Shop, 4 for Souveniers")
    if(direction == "1"):
        Lobby()
    if(direction == "2"):
        NaturalShop()
    if(direction == "3"):
        FarmShop*()
    if(direction == "4"):
        Souveniers()
    else:
        GiftShop()
def FarmShop():
    direction = input("You are in the Farm Shop. Where would you like to go? 1 for Farm, 2 for Shop")
    if(direction == 1):
        Farm()
    if(direction == 2):
        GiftShop()
    else:
        FarmShop()
def CropRoom():
    direction = input("You are in the crop room. 1 to return to Farm")
    if(direction == 1):
        Farm()
    else:
        CropRoom()
def FarmTech():
    direction = input("You are in farm tech. 1 for farm, 2 for tech")
    if(direction == 1):
        Farm()
    if(direction == 2):
        Technology()
    else:
        FarmTech
def Computers():
    direction = input("You are in the computer section. 1 to go back to tech section")
    if(direction == 1):
        Technology()
    else:
        Computers()
def AncientTech():
    direction = input("You are in ancient tech. 1 for tech, 2 for natural section.")
    if(direction == 1):
        Technology()
    if(direction == 2):
        Natural()
    else:
        AncientTech()
def Creatures():
    direction = input("You are in the Creatures Section. 1 to go back to the Natural Section.")
    if(direction == 1):
        Natural()
    else:
        Creatures()
def NaturalShop():
    direction = input("You are in the Natural Shop. 1 for Natural section, 2 for Shop")
    if(direction == 1):
        Natural()
    if(direction == 2):
        GiftShop()
    else:
        NaturalShop()
def Souveniers():
    direction = input("You are in the Souvenier section. 1 to go back to the Shop")
    if(direction == 1):
        GiftShop()
    else:
        Souveniers()

Lobby()