fish = input("What is your favorite fish to catch? ")
while(True):
    if(fish=="Largemouth bass"):
        print("you are basic")
    elif(fish== "Walleye"):
        print("You are strange")
    elif(fish== "Striper"):
        print("I am a large fan")
    elif(fish== "Smallmouth bass"):
        print("You are very seasoned")
    elif(fish== "Perch"):
        print("I'm sorry for you")
    elif(fish== "Bluegill"):
        print("I'm sorry for you")
    elif(fish== "Gar"):
        print("This is respectable")
    elif(fish== "Tuna"):
        print("You make too much money")
    elif(fish== "Sailfish"):
        print("You make too much money")
    elif(fish== "I don't fish"):
        print("You're a loser")
    elif(fish== "Swordfish"):
        print("You're too rich")
    elif(fish== "Crappie"):
        print("You are very smart")
    elif(fish== "Spoonbill"):
        print("Good Choice")
    elif(fish== "Catfish"):
        print("Good choice, me too")
    elif(fish== "Eel"):
        print("You're weird")
    elif(fish== "Shark"):
        print("You're a bad person")
    elif(fish== "Tree branches"):
        print("Mine too")
    elif(fish== "Whale"):
        print("Not a fish and you're a bad person")
    elif(fish== "Crawdad"):
        print("That's a crustation, good eatin though")
    elif(fish== "Crayfish"):
        print("it's called a crawdad")
    elif(fish== "Oscar"):
        print("Where???")
    elif(fish== "Carp"):
        print("Liar")
    else:
        print("stop trying to be unique")
        break
    