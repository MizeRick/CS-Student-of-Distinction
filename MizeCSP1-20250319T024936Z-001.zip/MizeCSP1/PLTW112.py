#The code will print "Hello there!"

#What does an input statement do?
# an input statement collects user input

#What is user_name and what is it used for?
# user name in this case is a variable that contains the user name

#What does a print statement do?
#Print outputs data in the form of text


#What is the goal of this program?
#To predict birth year based on age

#What type of data will the variables age, curr_year, and birth_year store?
#Integers

#What do you observe?
#There is an error  

#What do you think is the issue causing this error?
#Data type error, it is a string rather than an integer

#Run the program again. Do you still get the error?
#no

#Compare your code to your elbow partner’s code. Do the solutions differ? Explain.
#Yes, we have creative differences in our circles

import turtle as trtl

painter =  trtl.Turtle()
painter.pensize(5)



painter.penup()
painter.goto(0, 0)
painter.pendown()
painter.circle(50)
painter.penup()
painter.goto(50,0)
painter.pendown()
painter.circle(50)
painter.penup()
painter.goto(100,0)
painter.pendown()
painter.circle(50)
painter.penup()
painter.goto(-50,0)
painter.pendown()
painter.circle(50)
#Audi

wn = trtl.Screen()
wn.mainloop()

