


def celtofar(celcius):
    return(celcius * (9/5)+32)
def fartocel(Farenheit):
    return((Farenheit-32)*(5/9))
def areaofcircle(Radius):
    Radius = int(input("What is the radius? "))
    return(3.14 * Radius**2)
def areaofrec(length, width):
    length = int(input("what is the length? "))
    width = int(input("what is the width? "))
    return(width * length)
def areaoftri(Base, height):
    Base = int(input("what is the base? "))
    height = int(input("what is the height? "))
def evenorodd(Number):
    Number = int(input("what is your number? "))
    if(Number%2 == 0): 
        return("Your number is even")
    elif(Number%2 == 1):
        return("your number is odd")
    else:
        return("not a number")    
def Max(Num1,Num2,Num3):
    Num1 =int(input("What is your first number? "))
    Num2 =int(input("What is your first number? "))
    Num3 =int(input("What is your first number? "))
    if(Num1 > Num2 and Num1 > Num3):
        return("The biggest number is ",Num1)
    elif(Num2 > Num1 and Num2 > Num3):
        return("The biggest number is ",Num2)
    elif(Num3 > Num2 and Num3 > Num1):
        return("The biggest number is ",Num3)
    else:
        return("Wrong")