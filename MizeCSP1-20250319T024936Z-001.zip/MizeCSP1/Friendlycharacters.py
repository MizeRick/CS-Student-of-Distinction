
class Characters:
    def _init_(self, health, strength, sneak, intelligence, charisma):
        self.health = health
        self.strength = strength
        self.sneak = sneak
        self.intelligence = intelligence
        self.charisma = charisma

mentor = Characters(150,4,3,10,6)
informant = Characters(200,5,10,9,10)
tavernkeep = Characters(180,6,4,8,9)
