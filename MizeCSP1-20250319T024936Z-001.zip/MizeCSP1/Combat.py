import random

userhealth = 100
Son = 150

Spank = 30
Lightslap = 10
punch = 15
Spatula = 40
devtest = 5000

Cry = 20
Scream = 10
Insult = 7
CallCPS = 100

while(True):
    attack = random.randrange(1,5)
    userattack = input("How would you like to discipline your child? 1 = Spank, 2 = Light Slap, 3 = Punch, 4 = Spatula ")
    if(attack == 1):
        print("Your son cries")
        userhealth -= Cry
    elif(attack == 2):
        print("Your son screams")
        userhealth -= Scream
    elif(attack == 3):
        print("Your son insults you")
        userhealth -= Insult
    elif(attack == 4): 
        print("Your son calls CPS")
        userhealth -= CallCPS

    if(userattack == "1"):
        print("You Spank your son")
        Son -= Spank
    elif(userattack == "2"):
        print("You slap your child")
        Son -= Lightslap
    elif(userattack == "3"):
        print("you punch your son")
        Son -= punch
    elif(userattack == "4"):
        print("You hit your son with a spatula")
        Son -= Spatula
    elif(userattack == "5"):
        print("Devtest activated")
        Son -= devtest

    if(userhealth <= 0):
        print("You lose")
        break
    if(Son <= 0):
        print("You win")
        break