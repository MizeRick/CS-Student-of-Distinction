ToDo = []

def Addtask():
    addition = input("What task would you like to add? ")
    ToDo.append(addition)
    
def Completetask():
        complete = input("What task have you completed? ")
        if(complete in ToDo):
            ToDo.remove(complete) 
        else:
            pass


def Showlist():
    print(ToDo)

while True:
    choice = input("1 for Add task, 2 for remove task, 3 for print list, 4 for exit ")    
    if(choice == "1"):
        Addtask()
        continue
    elif(choice == "2"):
        Completetask()
        continue
    elif(choice == "3"):
        Showlist()
        continue
    elif(choice == "4"):
        break
    else: 
        print("invalid input, try again")
        continue