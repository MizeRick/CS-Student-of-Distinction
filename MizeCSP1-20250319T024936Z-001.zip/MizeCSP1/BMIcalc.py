
class BMI:
    global BMIcollect
    global BMIcalc
    global summary
    global underweightadvice
    global healthyadvice
    global overweightadvice
    global obeseadvice
    def __init__(self, height, weight):
        self.height = height
        self.weight = weight
    def BMIcollect():
        global height
        global weight
        while True:
            try:
                height = int(input("What is your height in inches? "))
                weight = int(input("What is your weight in pounds? "))
                BMIcalc()
            except:
                print("Please input a round number")

    def BMIcalc():
        global BMItrue
        global BMInum
        global Heightsq
        Heightsq = height **2
        BMInum = (weight/Heightsq)
        BMItrue = BMInum*703
        summary()
    def summary():
        if BMItrue <=19:
            print("You are likely underweight")
            underweightadvice()
        elif BMItrue >= 20 and BMItrue <= 25:
            print("You are likely healthy")
            healthyadvice()
        elif BMItrue >= 25 and BMItrue <= 30:
            print("You are likely overweight")
            overweightadvice()
        else:
            print("You are likely obese")
            obeseadvice()
    def underweightadvice():
        print("You are small.\nFind your caloric maintenence and begin to eat at least 200 calories over this limit daily.\nMake sure to track your macro and micronutrients and remain active in order to maintain a healthy lifestyle.")
        repeat()
    def healthyadvice():
        print("You are at a healthy weight.\nBegin to track your micro and macronutrients while remaining active in order to stay healthy")
        repeat()
    def overweightadvice():
        print("You are overweight.\nFind your caloric maintenence and begin to eat at least 300 under this daily.\n Track your micro and micronutrients while staying active in order to maintain a healthy lifestyle")
        repeat()
    def obeseadvice():
        print("You are obese\nFind your caloric maintenence and begin to eat at least 400 calories under this limit daily\n Track your micro and macronutrients while staying active to maintain a healthy lifestyle")
        repeat()
            
def repeat():
    repeatchoice = input("Would you like to do this again? 1 for yes, 2 for no ")
    if repeatchoice == "1":
        BMIcollect()
    else:
        print("Thank you for using my program.")

BMIcollect()


        