import random
lst = ['Rock', 'Paper', 'Scissors']
CompChoice=    random.choice(lst)
PlayerChoice= input("Rock, Paper, Scissors, Shoot! ")
if (CompChoice == "Rock" and PlayerChoice == "Paper"):
    print("You win!")
elif(CompChoice == "Scissors" and PlayerChoice == "Paper"):
    print("You Lose!")
elif(CompChoice == "Paper" and PlayerChoice == "Paper"):
    print("It's a tie!")
elif(CompChoice == "Rock" and PlayerChoice == "Scissors"):
    print("You Lose!")
elif(CompChoice == "Paper" and PlayerChoice == "Scissors"):
    print("You Win!")
elif(CompChoice == "Scissors" and PlayerChoice == "Scissors"):
    print("It's a tie!")
elif(CompChoice == "Rock" and PlayerChoice == "Rock"):
    print("It's a tie!")
elif(CompChoice == "Paper" and PlayerChoice == "Rock"):
    print("You Lose!")
elif(CompChoice == "Scissors" and PlayerChoice == "Rock"):
    print("You Win!")
else:
    print("Try again")