

#going to create a class with defining features for the player. The player will be able to print these features for each suspect later on to see who they want to put on trial
class character:
    def __init__(self, Hairtype, bloodtype, relationship):
        self.Hairtype = Hairtype
        self.bloodtype = bloodtype
        self.relationship = relationship

Owner = character("Black and straight","AB positive", "Employer of victim")
Roofer = character("Black and curly", "O negative", "Cousin of victim")
Butler = character("Dark and curly", "O negative", "Coworker of victim")

#Quick function to start the game
def begin():
    decision1 = input("Press any key to play ")
    print("Welcome detective, let me brief you on the current situation. \n The gardener at the lakeview mansion was murdered at 5:30. We were called and we believe the murderer is still on site \nI want you to go to the scene, investigate, and solve this murder before anyone else gets hurt. \nIt seems the victim put up a fight, there may be strong DNA traces on scene \nGood luck, detective")
    drive()

#The first player induced experience, a drive to the crime scene. This allows for a quick introduction to how the game will be played
def drive():
    while True:
        print("You start your vehicle")
        cardecision = input("You look at the clock, it's nearly 6PM. If you don't get there fast enough, it could mean degrading of evidence. \nHow fast will you drive? 1 for 5 under the speed limit, 2 for the speed limit, 3 for 7 over the speed limit, 4 for reckless. ")
        if cardecision == "1":
            late()
            break
        elif cardecision == "2":
            ontime()
            break
        elif cardecision == "3":
            Pulledover()
            break
        elif cardecision == "4":
            Chase()
            break
        else:
            print("Your vehicle dies, you must start it again")
            #immersive error correcting in case they do not answer with a valid response

def late():
    print("Arriving upon the crime scene late, it appears everyone has left but the officer guarding the site. Wind has blown away any micro evidence left behind \na light rain that started has washed away all the blood. \n You did not do your job, the murderer could not be caught")
    failure()
    #Adds punishment for bad decisions



#Values good decisions, this is the "vanilla" or basic route
def ontime():
    print("You arrive to the scene. \nIt is time to gather evidence")
    collection = input("What evidence would you like to collect? 1 for blood, 2 for hair ")
    if collection == "1":
        print("You collect the blood and analyze it, appears to be O negative \nThe wind picks up and blows the loose hair away")
        policestation()
    elif collection == "2":
        print("You collect the hair, it is curly and black \nThe wind and rain picks up and the blood is washed away")
        policestation()
    else:
        print("You were too slow to make a decision, wind and rain comes and the evidence is ruined \nThe murderer could not be caught")
        failure()

#Another way to punish bad decisions
def Pulledover():
    print("You are pulled over by a police officer. The situation escalates and you are shot. \nThe murderer could not be caught. ")
    failure()


#Optional route, offers risk for reward
def Chase():
    print("As you speed towards the scene, an officer pulls out behind you and begins chase")
    Chasedecision = input("Press 1 to pull over, press 2 to evade ")
    if Chasedecision == "2":
        print("The officer could not keep up, you arrive to the scene very early. \n All witnesses are present")
        early()
    else:
        Pulledover()

#Route that rewards risky players
def early():
    print("Arriving early, you collect all evidence. \n The hair on scene appears black and curly \n The blood on scene is type O negative")
    questioning = input("Most witnesses are in a rush to leave, you may only question one. \n 1 to question the Owner of the mansion, 2 to question the roofer, 3 to question the Butler")
    if questioning == "1":
        print("Now who will tend to my garden? There's always something I have to deal with")
        policestation()
    elif questioning == "2":
        print("He is my cousin, we grew up together, man.")
        policestation()
    elif questioning == "3":
        print("I simply know him from around the grounds. We applied for the same position, but clearly he could not compete with me. \n Recently he's been attempting to take my job, how pitiful")
        policestation()
    else:
        print("You were too slow, the witnesses left")
        policestation()
    

#This information does not matter unless you have found previous evidence to connect it to
def policestation():
    print("You get into your vehicle and drive to the police station with your new found evidence. \n You may now view the files on hand for each suspect.")
    print("Owner's File:", Owner.Hairtype,",", Owner.bloodtype, ",", Owner.relationship, "," )
    print("Roofer's File:", Roofer.Hairtype, ",", Roofer.bloodtype, ",", Roofer.relationship, ",")
    print("Butler's File:",Butler.Hairtype, ",", Butler.bloodtype, ",", Butler.relationship, ",")
    accusation()


#Final decision
def accusation():
    accuse = input("Who would you like to accuse? 1 for Owner, 2 for Roofer, 3 for Butler ")
    if accuse == "1":
        print("The owner is taken into custody. The next night while driving home, your brakes have been cut. \n The accident is fatal, the murderer was not caught")
        failure()
    elif accuse =="2":
        print("The roofer is taken into custory. The next night, he confesses to everything. He says they have been fighting since childhood. \n The murder was caught. \n Good Job, Detective")
        congrats()
    elif accuse == "3":
        print("The Butler is taken into custody. The next night while driving home, your brakes have been cut. \n The accident is fatal, the murderer was not caught")
        failure()
    else:
        print("You could not make a decision. \n The next night while driving home, your brakes have been cut. \n The accident is fatal, the murderer was not caught")
        failure()


#Correct final decision
def congrats():
    print("Good job, detective. Thank you for your help. \n Here is $1000. Keep up the good work")
    print("The end, thank you for playing")
    return


#Incorrect/failed to complete the game. Offers replay
def failure():
    print("You have failed to catch the murderer")
    fail = input("Would you like to play again? 1 for yes, 2 for no ")
    if fail == "1":
        begin()
    else:
        print("Thank you for playing.")


#Starts the game
begin()
