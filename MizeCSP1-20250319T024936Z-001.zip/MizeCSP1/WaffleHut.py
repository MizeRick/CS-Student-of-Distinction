Waffle = 4
Pancakes = 4
Omelette = 5
FriedEgg = 1.5
Burger = 5
Catfish = 5
Sirloin = 6
PhillyCheeseSteak = 6
FriedChicken = 6
BiscuitsandGravy = 4
Totalcost = 0

while(True):
    Order = input("Welcome to Waffle Hut, our menu inclues Waffle, Pancakes, Omelette, FriedEgg, Burger, Catfish, Sirloin, PhillyCheeseSteak, FriedChicken, and BiscuitsandGravy. What would you like to eat? ")
    if(Order == "Waffle"):
        print("That will be $ ", Waffle)
        Totalcost += Waffle
    elif(Order == "Pancakes"):
        print("That will be $ ", Pancakes)
        Totalcost+=Pancakes
    elif(Order == "Omelette"):
        print("That will be $", Omelette)
        Totalcost+=Omelette
    elif(Order == "FriedEgg"):
        print("That will be $", FriedEgg)
        Totalcost+=FriedEgg
    elif(Order == "Burger"):
        print("That will be $", Burger)
        Totalcost+=Burger
    elif(Order == "Catfish"):
        print("That will be $", Catfish)
        Totalcost+=Catfish
    elif(Order == "Sirloin"):
        print("That will be $", Sirloin)
        Totalcost+=Sirloin
    elif(Order == "PhillyCheeseSteak"):
        print("That will be $", PhillyCheeseSteak)
        Totalcost+=PhillyCheeseSteak
    elif(Order == "FriedChicken"):
        print("That will be $", FriedChicken)
        Totalcost+=FriedChicken
    elif(Order == "BiscuitsandGravy"):
        print("That will be $", BiscuitsandGravy)
        Totalcost+=BiscuitsandGravy
    else:
        print("try again, please respond with proper input")
    Done = input("Will that be all for you today? ")
    if(Done == "yes"):
        print("That is $", Totalcost)
        break
