


income = int(input("What is your annual income? "))
def Tracker():
    global expense1
    global expense2
    global expense3
    global expense4
    global expense5
    global expense6
    global Food
    global Housing
    global Entertainment
    global Savings 
    global Investments
    global Other
    
    expense1 = 0
    expense2 = 0
    expense3 = 0
    expense4 = 0
    expense5 = 0
    expense6 = 0
    Food = 0 
    Housing = 0
    Entertainment = 0
    Savings = 0 
    Investments = 0
    Other = 0
    while True:
        expense = int(input("What did you spend money on? 1 for Food, 2 for Housing, 3 for entertainment, 4 for Savings, 5 for investments, 6 for other, 7 for Done. "))
        if(expense == 1):
            expense1 = int(input("How much money did you spend on this? "))
            Food += expense1
            continue
        elif(expense == 2):
            expense2 = int(input("How much money did you spend on this? "))
            Housing += expense2
            continue
        elif(expense == 3):
            expense3 = int(input("How much money did you spend on this? "))
            Entertainment += expense3
            continue
        elif(expense == 4):
            expense4 = int(input("How much money did you spend on this? "))
            Savings += expense4
            continue
        elif(expense == 5):
            expense5 = int(input("How much money did you spend on this? "))
            Investments += expense5
            continue
        elif(expense == 6):
            expense6 = int(input("How much money did you spend on this? "))
            Other += expense6
            continue
        else:
            print("Calculating")
            summary()

def summary():
    print("Your annual income is", income)
    print("Of this income, you have spent", Food, "on Food")
    print("You have spent", Housing, "on Housing")
    print("You have spent", Entertainment, "on Entertainment")
    print("You have put", Savings, "into your Savings")
    print("You have invested", Investments)
    print("You have spent", Other, "on Other things")

    if(expense5 <= income/10):
        print("It looks like you have invested less than 10 percent of your anual income. Your goal is to do better next year")
    else:
        goal = input("Good job on investing, what is another goal you would like to accomplish?")


Tracker()