
p = float(input("What is your principal? "))
r = float(input("What is your monthly interest rate? "))
n = float(input("How many periods will you be paying for? "))

def loancalc(p, r, n):
    print (p*((r*(1+r)**n)/((1+r)**n)-1))

loancalc(p,r,n)