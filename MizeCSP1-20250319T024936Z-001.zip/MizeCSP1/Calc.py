Number1 = input("Give me a number ")
Number2 = input("Give me another number ")
Operator = input("give me an operator'-,+,*,/' ")
Number1 = float(Number1)
Number2 = float(Number2)
if(Operator == "-"):
    print(Number1-Number2)
elif(Operator == "+"):
    print(Number1+Number2)
elif(Operator == "*"):
    print(Number1*Number2)
elif(Operator == "/"):
    print(Number1/Number2)
else:
    print("Try again")

