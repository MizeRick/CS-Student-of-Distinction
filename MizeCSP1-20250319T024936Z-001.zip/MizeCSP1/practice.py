import math
input1 = float(input("What is the a of your Quadratic? "))
input2 = float(input("What is the b of your Quadratic? "))
input3 =float(input("What is the c of your Quadratic? "))
def Zero(a,b,c):
        print("Zeros are:")
        print(((-1*b) + (math.sqrt(math.pow(b,2)-((4)*(a)*(c)))))/(2*a))
        print(((-1*b) - (math.sqrt(math.pow(b,2)-((4)*(a)*(c)))))/(2*a))
Zero(a=input1, b=input2, c=input3)