import random
word = ""
correct= []
incorrect = []
def play():
    global word 
    global words 
    global Lform
    global incorrect
    global correct
    words = ["under", "sting", "jumps", "apple", "stump", "fish", "log", "liberate", "python"]
    while True:
        plays = input("Press 1 to play ")
        if plays == "1":
            correct.clear()
            incorrect.clear()
            word = random.choice(words)
            Lform = list(word)
            guess()
        else: 
            play()

def guess():
    global word
    while True:
        correct.sort
        Lform.sort
        if correct == Lform:
            print(word)
            print("You win")
            play()
            break
        if len(incorrect) >= 7:
            print("You lose")
            print(word)
            play()
            break
        guess = input("What letter would you like to guess? ")
        if guess in Lform:
            print("Good job, this guess was correct")
            correct.append(guess)
        elif guess not in Lform:
            print("Bad job, this guess was incorrect")
            incorrect.append(guess)

play()