while(True):
    number = input("give me a number ")
    number = int(number)

    Fizz = number%3
    Buzz = number%5
    if(Fizz ==0 and Buzz ==0):
        print("FizzBuzz")
        break
    elif(Fizz == 0):
        print("Fizz")
    elif(Buzz == 0):
        print("Buzz")
    elif(Fizz != 0):
        print("Your remainder is ", number)
    else:
        print("try again")
