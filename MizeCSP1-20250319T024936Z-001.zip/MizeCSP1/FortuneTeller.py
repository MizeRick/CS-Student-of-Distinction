import random
name = input("What is your name? ")


fortunes = ["You are likely to get divorced within your lifetime", "You are unlikely to get divorced in your lifetime", "Your fortune is blank"]

rand = random.randrange(1,10)
try:
    inc = int(input("What is your annual income? "))
    if(rand >=9):
        print("You are lucky and will go far in life")
    elif(inc <= 30000):
        print(fortunes[0])
    elif(inc > 30000):
        print(fortunes[1])
except:
      print("your fortune is blank")
