ar = [1,2,3,4,5,6,7,9,10,11,12,13,14,15]


def mergesort(arr):
    if len(ar) <=1 :
        return ar
    mid = len(ar)//2
    left = ar[:mid]
    right = ar[mid:]
    leftsorted = mergesort(left)
    rightsorted = mergesort(right)
    return merge(leftsorted, rightsorted)

def merge(left, right):
    sortedarr = []
    i = j = 0
    while i < len(left) and j < len(right):
        if left[i] < right[j]:
            sortedarr.append(left[i])
            i += 1
        else:
            sortedarr.append(right[j])
            j += 1
    sortedarr.extend(left[i:])
    sortedarr.extend(right[j:])

    return sortedarr

mergesort(ar)