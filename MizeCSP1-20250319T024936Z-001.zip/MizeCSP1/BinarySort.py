


def Binary_Search():
    arr = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30]
    low = 0
    high = len(arr) -1 
    mid = 0 
    while True:

            target = int(input("What is the target? "))
            while True:
                mid = (low + high)
                if mid % 2 == 1:
                     mid = mid/2
                     round(mid)
                     mid = int(mid)
                else:
                     mid = int(mid/2)
                if arr[mid] == target:
                    return(mid)
                elif arr[mid] > target:
                    high = mid-1
                elif arr[mid] < target:
                    low = mid+1
                    if low >= high:
                         return -1
                else:
                    return -1




var = Binary_Search()
if var == -1:
    print("Not Found")
else:
     print("Good job, target found")