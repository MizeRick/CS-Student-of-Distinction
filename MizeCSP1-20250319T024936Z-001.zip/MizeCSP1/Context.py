

play = input("Press 1 to play ")
while True:
    if(play == "1"):
        print("Wlecome to Eldoria!")
        break
    else:
        continue

print("In Eldoria, a once-vibrant kingdom, power struggles have left the land in disarray.")
print("After the royal family vanished, various factions-each with their own ambitions-now vie for dominance.")
print("The Heart of Aether, a legendary artifact rumored to bestow great power, is said to be hidden somewhere within the kingdom.")

