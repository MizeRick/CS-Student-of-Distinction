def collect():
    global age
    global time
    global privacy
    global apps
    while True:
        try:
            age = int(input("what is your age? "))
            time = int(input("How many hours a day do you spend on your phone? "))
            apps = int(input("How many social media apps do you use? "))
            summary()       
        except ValueError:
                print("Do not enter invalid inputs")

def summary():
    print("Thank you for your input, your data is valuable. ")
    if age <= 13:
        print("You are too young for this data to be applicable, please exit this software")
        exit()
    else:
        print("The following is your summary")
    if time >= 3:
        print("You are on your phone too much")
    else:
        print("Continue to watch your screentime")
    if apps >= 4:
        print("Be safe using so many online platforms, the more exposure, the more risk you put yourself at.")
    else:
        print("Continue to be vigilant regarding social media")
    print("REVIEW PRIVACY SETTINGS. YOU MUST KNOW DATA SECURITY TO BE ONLINE")






collect()
 