def castle():
    print("You arrive to the castle")

def forest():
    print("You arrive in the forest")

def swamps():
    print("You arive in the swamps")
    decision8 =input("There is a large snake, would you like to fight it? 1 for yes, 2 for no ")
    if(decision8 == "1"):
        SnakeFight()
    if(decision8 == "2"):
        while True:
            decision9 = input("Where do  you run? 1 for town, 2 for lake")
            if(decision9 == "1"):
                town2()
            elif(decision9 == "2"):
                lake2()
            else:
                print("invalid input")
                continue



def caverns():
    print("You arrive to the caverns")
    



def forest():
    print("You arrive in the forest")
    print("After wandering for hours you decided you got lost")
    print("you need to chose a direction to get out of the forest")
    
    while True:
        decision12 = input("What way would you like to go? 1 for Left, 2 for right, 3 for straight")
        if(decision12 == "1"):
            print("you start to walk left marking each tree as you pass, minutes later you start to see those same markings.")
            print("You walked in a circle, you are back to square 1")
            forest()

        elif(decision12 == "2"):
            print("You decide to go right")
            print("Each step you take seems weary but you continue either way")
            print("After minutes of walking, you finally discover the caverns")
            caverns()

        elif(decision12 == "3"):
            print("The path was clear, or so you thought.")
            print("Soon you hear footsteps, but they aren't yours. These are heavier...louder...and getting closer")
            print("Suddenly you hear a ROAR.")
            print("You turn around and see a bear")
            while True:
                decision13 = input("You come to the conclusion that you need to cause a distraction. What will you do? 1 sacrifice the cat, 2 for hide, 3 for fight")
                
                if (decision13 == "1"):
                    print("You throw the cat at the bear")
                    print("stunned by your cowardice, the bear lunges at you")
                    awakening()

                elif (decision13 == "2"):
                    print("You decide to hide.")
                    print("You hide behind a large rock, careful not to make a sound.")
                    print("As time passes by the air becomes still, you know that the bear is gone but when you get up you realize your back to square 1")
                    forest()

                elif(decision13 == "3"):
                    if (User.strength >= 7):
                        print("You won!")
                        print("But you realize your back to where you started")
                        forest()
        else:
            print("Invalid input")
            continue

        
            









def lastrespite():
    print("You arrive to a campfire")
    print("In the distance you see a familiar face")
    print("It's the old man from the barn")
    while True:
        decisionfire = input("Do you chose to talk to the old man? 1 for talk to the old man, 2 for no i don't want to talk to him")
        
        if(decisionfire == "1"):
            print("You chose to approach and talk to the old man")
            print("The old man talks about preparing you for the battle that comes ahead")
            print("You listen and agree with each word of the old man.")
            User.health += 100
            User.strength += 1
            User.sneak += 1
            User.intelligence += 1
            User.charisma += 1
            
        else:
            print("You chose not to talk to the old man and instead walk by him")
            
            castle()
        
        







def bandittown():
    print("you arrive into a town of bandits")
    print("The area was anything but nice, with runned down buildings and the lingering scent of alcohol")
    print("As you walk deeper and deeper into the town, you see a tall shadow")
    print("you stop, afraid of what is to happen next")
    print("As it gets closer, the figure becomes more defined. You come face to face with a scrawny man, whos face is unknown, hidden by the thick black cloak")
    print("He starts to say, 'I will tell you how to get to the castle, if you have what I need.' ")
    
    item = "sword"
    if item in invetory:
        inventory.remove("sword")
        print("follow the path northeast to your last respite and you will find an entrance.")
    
    else:
        print("You don't have what I need. Be on your way.")






